﻿function () {
    emit(this.MovieID, { Count: 1, Rating: this.Value });
}