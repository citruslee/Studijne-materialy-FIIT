﻿function (key, values) {
    var count = 0;
    var rating = 0.0;

    values.forEach(function (value) {
        count += value.Count;
        rating += value.Rating * value.Count;
    });

    return { Count: count, Rating: rating / count };
}