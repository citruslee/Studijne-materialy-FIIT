﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Threading;
using System.Diagnostics;
using System.Collections;

namespace MongoDBExample
{
    public partial class MainForm : Form
    {
        private readonly Controller controller = new Controller();
        private readonly Stopwatch watch = new Stopwatch();

        public MainForm()
        {
            InitializeComponent();
        }

        delegate void OutputWriteCallback(object data, bool scrollToEnd);
        void OutputWrite(object data, bool scrollToEnd = false)
        {
            if (InvokeRequired)
            {
                Invoke(new OutputWriteCallback(OutputWrite), new object[] { data, scrollToEnd });
            }
            else
            {
                outputTextBox.Text = data.ToString();

                if (scrollToEnd)
                {
                    outputTextBox.Select(outputTextBox.Text.Length, 0);
                    outputTextBox.ScrollToCaret();
                }
            }
        }

        delegate void OutputAppendCallback(string text);
        void OutputAppend(string text)
        {
            if (InvokeRequired)
            {
                Invoke(new OutputAppendCallback(OutputAppend), new object[] { text });
            }
            else
            {
                outputTextBox.Text += "\r\n" + text;
                outputTextBox.Select(outputTextBox.Text.Length, 0);
                outputTextBox.ScrollToCaret();
            }
        }

        delegate void OutputWithTimeCallback(object result, long time);
        void OutputWithTime(object result, long time)
        {
            if (InvokeRequired)
            {
                Invoke(new OutputWithTimeCallback(OutputWithTime), new object[] { result, time});
            }
            else
            {
                outputTextBox.Text = string.Format("{0} [{1} ms]", result, time);
            }
        }

        delegate void OutputClearCallback();
        void OutputClear()
        {
            if (InvokeRequired)
            {
                Invoke(new OutputClearCallback(OutputClear), new object[] { });
            }
            else
            {
                outputTextBox.Text = string.Empty;
            }
        }

        delegate void OutputIEnumerableCallback(IEnumerable enumerable);
        void OutputIEnumerable(IEnumerable enumerable)
        {
            if (InvokeRequired)
            {
                Invoke(new OutputIEnumerableCallback(OutputIEnumerable), new object[] { enumerable });
            }
            else
            {
                bool first = true;
                foreach (var obj in enumerable)
                {
                    if (first)
                    {
                        outputTextBox.Text = obj.ToString();
                        first = false;
                    }
                    else
                    {
                        outputTextBox.Text += "\r\n" + obj.ToString();
                    }
                }
            }
        }

        private void dataFileTextBox_TextChanged(object sender, EventArgs e)
        {            
            loadButton.Enabled = File.Exists(dataFileTextBox.Text);
        }

        private void openDataButton_Click(object sender, EventArgs e)
        {
            openDataFileDialog.FileName = dataFileTextBox.Text;

            if (openDataFileDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                dataFileTextBox.Text = openDataFileDialog.FileName;
            }
        }

        private void loadButton_Click(object sender, EventArgs e)
        {
            Thread th = new Thread(new ParameterizedThreadStart(Load));
            outputTextBox.Text += "Reading raitings...";
            th.Start(dataFileTextBox.Text);
        }

        void Load(object param)
        {
            int count = 0;
            Queue<Rating> ratings = new Queue<Rating>();            

            foreach (var line in File.ReadLines((string)param))
            {
                if (ratings.Count >= 100000)
                {
                    OutputAppend("Inserting ratings...");
                    controller.InsertBatch(ratings);
                    OutputAppend(count.ToString("##,#") + " ratings added!\r\nReading raitings...");
                    ratings.Clear();
                }

                ratings.Enqueue(new Rating(line));
                count++;
            }

            OutputAppend("Inserting ratings...");

            controller.InsertBatch(ratings);

            OutputAppend("Finished: " + count.ToString("##,#") + " ratings added!");
        }

        private void countButton_Click(object sender, EventArgs e)
        {
            OutputClear();
            watch.Reset();
            watch.Start();
            var result = controller.Count();
            watch.Stop();
            OutputWithTime(result, watch.ElapsedMilliseconds);
        }

        private void countTopQueryDocumentButton_Click(object sender, EventArgs e)
        {
            OutputClear();
            watch.Reset();
            watch.Start();
            var result = controller.CountTopQueryDocument();
            watch.Stop();
            OutputWithTime(result, watch.ElapsedMilliseconds);
        }

        private void countTopQueryEQButton_Click(object sender, EventArgs e)
        {
            OutputClear();
            watch.Reset();
            watch.Start();
            var result = controller.CountTopQueryEQ();
            watch.Stop();
            OutputWithTime(result, watch.ElapsedMilliseconds);
        }

        private void countMiddleButton_Click(object sender, EventArgs e)
        {
            OutputClear();
            watch.Reset();
            watch.Start();
            var result = controller.CountMiddle();
            watch.Stop();
            OutputWithTime(result, watch.ElapsedMilliseconds);
        }

        private void countMiddleMoviesButton_Click(object sender, EventArgs e)
        {
            OutputClear();
            watch.Reset();
            watch.Start();
            var result = controller.CountMiddleMovies();
            watch.Stop();
            OutputWithTime(result, watch.ElapsedMilliseconds);
        }

        private void findOneButton_Click(object sender, EventArgs e)
        {
            OutputClear();
            watch.Reset();
            watch.Start();
            var result = controller.FindFirst();
            watch.Stop();
            OutputWithTime(result, watch.ElapsedMilliseconds);
        }

        private void select1st10Button_Click(object sender, EventArgs e)
        {
            OutputClear();
            watch.Reset();
            watch.Start();
            var result = controller.FindFirst10();
            watch.Stop();
            OutputIEnumerable(result);
        }

        private void select2nd10Button_Click(object sender, EventArgs e)
        {
            OutputClear();
            watch.Reset();
            watch.Start();
            var result = controller.FindSecond10();
            watch.Stop();
            OutputIEnumerable(result);
        }

        private void select1st10DescButton_Click(object sender, EventArgs e)
        {
            OutputClear();
            watch.Reset();
            watch.Start();
            var result = controller.FindLast10();
            watch.Stop();
            OutputIEnumerable(result);
        }

        private void update1stSaveButton_Click(object sender, EventArgs e)
        {
            OutputClear();
            watch.Reset();
            watch.Start();
            var result = controller.UpdateFirstSave();
            watch.Stop();
            OutputWithTime(result, watch.ElapsedMilliseconds);
        }

        private void update1stUpdateButton_Click(object sender, EventArgs e)
        {
            OutputClear();
            watch.Reset();
            watch.Start();
            var result = controller.UpdateFirstAtomic();
            watch.Stop();
            OutputWithTime(result, watch.ElapsedMilliseconds);
        }

        private void updateMultipleButton_Click(object sender, EventArgs e)
        {
            OutputClear();
            watch.Reset();
            watch.Start();
            var result = controller.UpdateFirst10();
            watch.Stop();
            OutputIEnumerable(result);
        }

        private void findAndModifyOldButton_Click(object sender, EventArgs e)
        {
            OutputClear();
            watch.Reset();
            watch.Start();
            var result = controller.FindAndModifyBefore();
            watch.Stop();
            OutputWithTime(result, watch.ElapsedMilliseconds);
        }

        private void findAndModifyNewButton_Click(object sender, EventArgs e)
        {
            OutputClear();
            watch.Reset();
            watch.Start();
            var result = controller.FindAndModifyAfter();
            watch.Stop();
            OutputWithTime(result, watch.ElapsedMilliseconds);
        }

        private void mapReduceButton_Click(object sender, EventArgs e)
        {
            OutputClear();
            Thread th = new Thread(new ParameterizedThreadStart(MapReduceWorker));
            th.Start(dataFileTextBox.Text);
            currentOpTimer.Enabled = true;
        }

        private void MapReduceWorker(object param)
        {
            var result = controller.MapReduce();
            currentOpTimer.Enabled = false;
            OutputClear();
            OutputWrite(result);
        }

        private void mapReduceFinalizeButton_Click(object sender, EventArgs e)
        {
            OutputClear();
            Thread th = new Thread(new ParameterizedThreadStart(MapReduceFinalizeWorker));
            th.Start(dataFileTextBox.Text);
            currentOpTimer.Enabled = true;
        }

        private void MapReduceFinalizeWorker(object param)
        {
            var result = controller.MapReduceFinalize();
            currentOpTimer.Enabled = false;
            OutputWrite(result);
        }

        private void currentOpTimer_Tick(object sender, EventArgs e)
        {
            OutputWrite(controller.GetCurrentOp(), true);
        }
    }
}
