﻿function (key, value) {
    return { Rating: value.Rating / value.Count };
}