﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson.Serialization.IdGenerators;
using MongoDB.Bson;

namespace MongoDBExample
{
    class Rating
    {
        private static string[] separator = new string[] { "::" };

        public Rating()
        {
        }

        public Rating(string ratingLine)
        {
            var attributes = ratingLine.Split(separator, StringSplitOptions.None);

            UserID = int.Parse(attributes[0]);
            MovieID = int.Parse(attributes[1]);
            Value = int.Parse(attributes[2]);
            Timestamp = long.Parse(attributes[3]);
        }

        [BsonId(IdGenerator = typeof(BsonObjectIdGenerator))]
        public BsonObjectId ID { get; set; }

        public int UserID { get; set; }

        public int MovieID { get; set; }

        public int Value { get; set; }

        public long Timestamp { get; set; }

        public override string ToString()
        {
            return string.Format("{0}::{1}::{2}::{3}::{4}", 
                ID, UserID, MovieID, Value, Timestamp);
        }
    }
}
