﻿namespace MongoDBExample
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.splitContainer = new System.Windows.Forms.SplitContainer();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.loadTabPage = new System.Windows.Forms.TabPage();
            this.loadButton = new System.Windows.Forms.Button();
            this.openDataButton = new System.Windows.Forms.Button();
            this.dataFileTextBox = new System.Windows.Forms.TextBox();
            this.executeCodetabPage = new System.Windows.Forms.TabPage();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.countButton = new System.Windows.Forms.Button();
            this.countTopQueryDocumentButton = new System.Windows.Forms.Button();
            this.countTopQueryEQButton = new System.Windows.Forms.Button();
            this.countMiddleButton = new System.Windows.Forms.Button();
            this.countMiddleMoviesButton = new System.Windows.Forms.Button();
            this.findOneButton = new System.Windows.Forms.Button();
            this.select1st10Button = new System.Windows.Forms.Button();
            this.select2nd10Button = new System.Windows.Forms.Button();
            this.select1st10DescButton = new System.Windows.Forms.Button();
            this.update1stSaveButton = new System.Windows.Forms.Button();
            this.update1stUpdateButton = new System.Windows.Forms.Button();
            this.updateMultipleButton = new System.Windows.Forms.Button();
            this.findAndModifyOldButton = new System.Windows.Forms.Button();
            this.findAndModifyNewButton = new System.Windows.Forms.Button();
            this.mapReduceButton = new System.Windows.Forms.Button();
            this.mapReduceFinalizeButton = new System.Windows.Forms.Button();
            this.outputTextBox = new System.Windows.Forms.TextBox();
            this.openDataFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.openCSFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.openJSFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.currentOpTimer = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).BeginInit();
            this.splitContainer.Panel1.SuspendLayout();
            this.splitContainer.Panel2.SuspendLayout();
            this.splitContainer.SuspendLayout();
            this.tabControl.SuspendLayout();
            this.loadTabPage.SuspendLayout();
            this.executeCodetabPage.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer
            // 
            this.splitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer.Location = new System.Drawing.Point(0, 0);
            this.splitContainer.Name = "splitContainer";
            this.splitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer.Panel1
            // 
            this.splitContainer.Panel1.Controls.Add(this.tabControl);
            // 
            // splitContainer.Panel2
            // 
            this.splitContainer.Panel2.Controls.Add(this.outputTextBox);
            this.splitContainer.Size = new System.Drawing.Size(1008, 663);
            this.splitContainer.SplitterDistance = 238;
            this.splitContainer.TabIndex = 0;
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.loadTabPage);
            this.tabControl.Controls.Add(this.executeCodetabPage);
            this.tabControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tabControl.Location = new System.Drawing.Point(0, 0);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(1008, 238);
            this.tabControl.TabIndex = 0;
            // 
            // loadTabPage
            // 
            this.loadTabPage.Controls.Add(this.loadButton);
            this.loadTabPage.Controls.Add(this.openDataButton);
            this.loadTabPage.Controls.Add(this.dataFileTextBox);
            this.loadTabPage.Location = new System.Drawing.Point(4, 40);
            this.loadTabPage.Name = "loadTabPage";
            this.loadTabPage.Padding = new System.Windows.Forms.Padding(3);
            this.loadTabPage.Size = new System.Drawing.Size(1000, 194);
            this.loadTabPage.TabIndex = 0;
            this.loadTabPage.Text = "Load Data";
            this.loadTabPage.UseVisualStyleBackColor = true;
            // 
            // loadButton
            // 
            this.loadButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.loadButton.AutoSize = true;
            this.loadButton.Enabled = false;
            this.loadButton.Location = new System.Drawing.Point(877, 147);
            this.loadButton.Name = "loadButton";
            this.loadButton.Size = new System.Drawing.Size(115, 41);
            this.loadButton.TabIndex = 2;
            this.loadButton.Text = "Load";
            this.loadButton.UseVisualStyleBackColor = true;
            this.loadButton.Click += new System.EventHandler(this.loadButton_Click);
            // 
            // openDataButton
            // 
            this.openDataButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.openDataButton.Location = new System.Drawing.Point(947, 6);
            this.openDataButton.Name = "openDataButton";
            this.openDataButton.Size = new System.Drawing.Size(47, 38);
            this.openDataButton.TabIndex = 1;
            this.openDataButton.Text = "...";
            this.openDataButton.UseVisualStyleBackColor = true;
            this.openDataButton.Click += new System.EventHandler(this.openDataButton_Click);
            // 
            // dataFileTextBox
            // 
            this.dataFileTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataFileTextBox.Location = new System.Drawing.Point(8, 6);
            this.dataFileTextBox.Name = "dataFileTextBox";
            this.dataFileTextBox.Size = new System.Drawing.Size(933, 38);
            this.dataFileTextBox.TabIndex = 0;
            this.dataFileTextBox.TextChanged += new System.EventHandler(this.dataFileTextBox_TextChanged);
            // 
            // executeCodetabPage
            // 
            this.executeCodetabPage.Controls.Add(this.flowLayoutPanel1);
            this.executeCodetabPage.Location = new System.Drawing.Point(4, 40);
            this.executeCodetabPage.Name = "executeCodetabPage";
            this.executeCodetabPage.Padding = new System.Windows.Forms.Padding(3);
            this.executeCodetabPage.Size = new System.Drawing.Size(1000, 194);
            this.executeCodetabPage.TabIndex = 1;
            this.executeCodetabPage.Text = "Execute Code";
            this.executeCodetabPage.UseVisualStyleBackColor = true;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.Controls.Add(this.countButton);
            this.flowLayoutPanel1.Controls.Add(this.countTopQueryDocumentButton);
            this.flowLayoutPanel1.Controls.Add(this.countTopQueryEQButton);
            this.flowLayoutPanel1.Controls.Add(this.countMiddleButton);
            this.flowLayoutPanel1.Controls.Add(this.countMiddleMoviesButton);
            this.flowLayoutPanel1.Controls.Add(this.findOneButton);
            this.flowLayoutPanel1.Controls.Add(this.select1st10Button);
            this.flowLayoutPanel1.Controls.Add(this.select2nd10Button);
            this.flowLayoutPanel1.Controls.Add(this.select1st10DescButton);
            this.flowLayoutPanel1.Controls.Add(this.update1stSaveButton);
            this.flowLayoutPanel1.Controls.Add(this.update1stUpdateButton);
            this.flowLayoutPanel1.Controls.Add(this.updateMultipleButton);
            this.flowLayoutPanel1.Controls.Add(this.findAndModifyOldButton);
            this.flowLayoutPanel1.Controls.Add(this.findAndModifyNewButton);
            this.flowLayoutPanel1.Controls.Add(this.mapReduceButton);
            this.flowLayoutPanel1.Controls.Add(this.mapReduceFinalizeButton);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(3, 3);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(994, 188);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // countButton
            // 
            this.countButton.AutoSize = true;
            this.countButton.Location = new System.Drawing.Point(3, 3);
            this.countButton.Name = "countButton";
            this.countButton.Size = new System.Drawing.Size(115, 41);
            this.countButton.TabIndex = 0;
            this.countButton.Text = "Count";
            this.countButton.UseVisualStyleBackColor = true;
            this.countButton.Click += new System.EventHandler(this.countButton_Click);
            // 
            // countTopQueryDocumentButton
            // 
            this.countTopQueryDocumentButton.AutoSize = true;
            this.countTopQueryDocumentButton.Location = new System.Drawing.Point(124, 3);
            this.countTopQueryDocumentButton.Name = "countTopQueryDocumentButton";
            this.countTopQueryDocumentButton.Size = new System.Drawing.Size(372, 41);
            this.countTopQueryDocumentButton.TabIndex = 3;
            this.countTopQueryDocumentButton.Text = "Count Top - QueryDocument";
            this.countTopQueryDocumentButton.UseVisualStyleBackColor = true;
            this.countTopQueryDocumentButton.Click += new System.EventHandler(this.countTopQueryDocumentButton_Click);
            // 
            // countTopQueryEQButton
            // 
            this.countTopQueryEQButton.AutoSize = true;
            this.countTopQueryEQButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.countTopQueryEQButton.Location = new System.Drawing.Point(502, 3);
            this.countTopQueryEQButton.Name = "countTopQueryEQButton";
            this.countTopQueryEQButton.Size = new System.Drawing.Size(295, 41);
            this.countTopQueryEQButton.TabIndex = 4;
            this.countTopQueryEQButton.Text = "Count Top - Query.EQ";
            this.countTopQueryEQButton.UseVisualStyleBackColor = true;
            this.countTopQueryEQButton.Click += new System.EventHandler(this.countTopQueryEQButton_Click);
            // 
            // countMiddleButton
            // 
            this.countMiddleButton.AutoSize = true;
            this.countMiddleButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.countMiddleButton.Location = new System.Drawing.Point(803, 3);
            this.countMiddleButton.Name = "countMiddleButton";
            this.countMiddleButton.Size = new System.Drawing.Size(183, 41);
            this.countMiddleButton.TabIndex = 5;
            this.countMiddleButton.Text = "Count Middle";
            this.countMiddleButton.UseVisualStyleBackColor = true;
            this.countMiddleButton.Click += new System.EventHandler(this.countMiddleButton_Click);
            // 
            // countMiddleMoviesButton
            // 
            this.countMiddleMoviesButton.AutoSize = true;
            this.countMiddleMoviesButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.countMiddleMoviesButton.Location = new System.Drawing.Point(3, 50);
            this.countMiddleMoviesButton.Name = "countMiddleMoviesButton";
            this.countMiddleMoviesButton.Size = new System.Drawing.Size(292, 41);
            this.countMiddleMoviesButton.TabIndex = 6;
            this.countMiddleMoviesButton.Text = "Count Middle - Movies";
            this.countMiddleMoviesButton.UseVisualStyleBackColor = true;
            this.countMiddleMoviesButton.Click += new System.EventHandler(this.countMiddleMoviesButton_Click);
            // 
            // findOneButton
            // 
            this.findOneButton.AutoSize = true;
            this.findOneButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.findOneButton.Location = new System.Drawing.Point(301, 50);
            this.findOneButton.Name = "findOneButton";
            this.findOneButton.Size = new System.Drawing.Size(68, 41);
            this.findOneButton.TabIndex = 7;
            this.findOneButton.Text = "1st ";
            this.findOneButton.UseVisualStyleBackColor = true;
            this.findOneButton.Click += new System.EventHandler(this.findOneButton_Click);
            // 
            // select1st10Button
            // 
            this.select1st10Button.AutoSize = true;
            this.select1st10Button.Location = new System.Drawing.Point(375, 50);
            this.select1st10Button.Name = "select1st10Button";
            this.select1st10Button.Size = new System.Drawing.Size(115, 41);
            this.select1st10Button.TabIndex = 1;
            this.select1st10Button.Text = "1st 10";
            this.select1st10Button.UseVisualStyleBackColor = true;
            this.select1st10Button.Click += new System.EventHandler(this.select1st10Button_Click);
            // 
            // select2nd10Button
            // 
            this.select2nd10Button.AutoSize = true;
            this.select2nd10Button.Location = new System.Drawing.Point(496, 50);
            this.select2nd10Button.Name = "select2nd10Button";
            this.select2nd10Button.Size = new System.Drawing.Size(115, 41);
            this.select2nd10Button.TabIndex = 2;
            this.select2nd10Button.Text = "2nd 10";
            this.select2nd10Button.UseVisualStyleBackColor = true;
            this.select2nd10Button.Click += new System.EventHandler(this.select2nd10Button_Click);
            // 
            // select1st10DescButton
            // 
            this.select1st10DescButton.AutoSize = true;
            this.select1st10DescButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.select1st10DescButton.Location = new System.Drawing.Point(617, 50);
            this.select1st10DescButton.Name = "select1st10DescButton";
            this.select1st10DescButton.Size = new System.Drawing.Size(113, 41);
            this.select1st10DescButton.TabIndex = 8;
            this.select1st10DescButton.Text = "Last 10";
            this.select1st10DescButton.UseVisualStyleBackColor = true;
            this.select1st10DescButton.Click += new System.EventHandler(this.select1st10DescButton_Click);
            // 
            // update1stSaveButton
            // 
            this.update1stSaveButton.AutoSize = true;
            this.update1stSaveButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.update1stSaveButton.Location = new System.Drawing.Point(736, 50);
            this.update1stSaveButton.Name = "update1stSaveButton";
            this.update1stSaveButton.Size = new System.Drawing.Size(248, 41);
            this.update1stSaveButton.TabIndex = 9;
            this.update1stSaveButton.Text = "Update 1st  - Save";
            this.update1stSaveButton.UseVisualStyleBackColor = true;
            this.update1stSaveButton.Click += new System.EventHandler(this.update1stSaveButton_Click);
            // 
            // update1stUpdateButton
            // 
            this.update1stUpdateButton.AutoSize = true;
            this.update1stUpdateButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.update1stUpdateButton.Location = new System.Drawing.Point(3, 97);
            this.update1stUpdateButton.Name = "update1stUpdateButton";
            this.update1stUpdateButton.Size = new System.Drawing.Size(262, 41);
            this.update1stUpdateButton.TabIndex = 10;
            this.update1stUpdateButton.Text = "Update 1st - Atomic";
            this.update1stUpdateButton.UseVisualStyleBackColor = true;
            this.update1stUpdateButton.Click += new System.EventHandler(this.update1stUpdateButton_Click);
            // 
            // updateMultipleButton
            // 
            this.updateMultipleButton.AutoSize = true;
            this.updateMultipleButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.updateMultipleButton.Location = new System.Drawing.Point(271, 97);
            this.updateMultipleButton.Name = "updateMultipleButton";
            this.updateMultipleButton.Size = new System.Drawing.Size(212, 41);
            this.updateMultipleButton.TabIndex = 11;
            this.updateMultipleButton.Text = "Update Multiple";
            this.updateMultipleButton.UseVisualStyleBackColor = true;
            this.updateMultipleButton.Click += new System.EventHandler(this.updateMultipleButton_Click);
            // 
            // findAndModifyOldButton
            // 
            this.findAndModifyOldButton.AutoSize = true;
            this.findAndModifyOldButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.findAndModifyOldButton.Location = new System.Drawing.Point(489, 97);
            this.findAndModifyOldButton.Name = "findAndModifyOldButton";
            this.findAndModifyOldButton.Size = new System.Drawing.Size(357, 41);
            this.findAndModifyOldButton.TabIndex = 12;
            this.findAndModifyOldButton.Text = "Find and Modify - Old Value";
            this.findAndModifyOldButton.UseVisualStyleBackColor = true;
            this.findAndModifyOldButton.Click += new System.EventHandler(this.findAndModifyOldButton_Click);
            // 
            // findAndModifyNewButton
            // 
            this.findAndModifyNewButton.AutoSize = true;
            this.findAndModifyNewButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.findAndModifyNewButton.Location = new System.Drawing.Point(3, 144);
            this.findAndModifyNewButton.Name = "findAndModifyNewButton";
            this.findAndModifyNewButton.Size = new System.Drawing.Size(370, 41);
            this.findAndModifyNewButton.TabIndex = 13;
            this.findAndModifyNewButton.Text = "Find and Modify - New Value";
            this.findAndModifyNewButton.UseVisualStyleBackColor = true;
            this.findAndModifyNewButton.Click += new System.EventHandler(this.findAndModifyNewButton_Click);
            // 
            // mapReduceButton
            // 
            this.mapReduceButton.AutoSize = true;
            this.mapReduceButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.mapReduceButton.Location = new System.Drawing.Point(379, 144);
            this.mapReduceButton.Name = "mapReduceButton";
            this.mapReduceButton.Size = new System.Drawing.Size(170, 41);
            this.mapReduceButton.TabIndex = 14;
            this.mapReduceButton.Text = "MapReduce";
            this.mapReduceButton.UseVisualStyleBackColor = true;
            this.mapReduceButton.Click += new System.EventHandler(this.mapReduceButton_Click);
            // 
            // mapReduceFinalizeButton
            // 
            this.mapReduceFinalizeButton.AutoSize = true;
            this.mapReduceFinalizeButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.mapReduceFinalizeButton.Location = new System.Drawing.Point(555, 144);
            this.mapReduceFinalizeButton.Name = "mapReduceFinalizeButton";
            this.mapReduceFinalizeButton.Size = new System.Drawing.Size(264, 41);
            this.mapReduceFinalizeButton.TabIndex = 15;
            this.mapReduceFinalizeButton.Text = "MapReduceFinalize";
            this.mapReduceFinalizeButton.UseVisualStyleBackColor = true;
            this.mapReduceFinalizeButton.Click += new System.EventHandler(this.mapReduceFinalizeButton_Click);
            // 
            // outputTextBox
            // 
            this.outputTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.outputTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.outputTextBox.Location = new System.Drawing.Point(0, 0);
            this.outputTextBox.Multiline = true;
            this.outputTextBox.Name = "outputTextBox";
            this.outputTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.outputTextBox.Size = new System.Drawing.Size(1008, 421);
            this.outputTextBox.TabIndex = 0;
            // 
            // openDataFileDialog
            // 
            this.openDataFileDialog.FileName = "openFileDialog";
            this.openDataFileDialog.Filter = "Dat files|*.dat|All files|*.*";
            // 
            // openCSFileDialog
            // 
            this.openCSFileDialog.FileName = "openFileDialog";
            this.openCSFileDialog.Filter = "C# files|*.cs|All files|*.*";
            // 
            // openJSFileDialog
            // 
            this.openJSFileDialog.FileName = "openFileDialog";
            this.openJSFileDialog.Filter = "JScript files|*.js|All files|*.*";
            // 
            // currentOpTimer
            // 
            this.currentOpTimer.Interval = 10000;
            this.currentOpTimer.Tick += new System.EventHandler(this.currentOpTimer_Tick);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1008, 663);
            this.Controls.Add(this.splitContainer);
            this.Name = "MainForm";
            this.Text = "MongoDB Example";
            this.splitContainer.Panel1.ResumeLayout(false);
            this.splitContainer.Panel2.ResumeLayout(false);
            this.splitContainer.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).EndInit();
            this.splitContainer.ResumeLayout(false);
            this.tabControl.ResumeLayout(false);
            this.loadTabPage.ResumeLayout(false);
            this.loadTabPage.PerformLayout();
            this.executeCodetabPage.ResumeLayout(false);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer;
        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage loadTabPage;
        private System.Windows.Forms.TabPage executeCodetabPage;
        private System.Windows.Forms.OpenFileDialog openDataFileDialog;
        private System.Windows.Forms.Button openDataButton;
        private System.Windows.Forms.TextBox dataFileTextBox;
        private System.Windows.Forms.OpenFileDialog openCSFileDialog;
        private System.Windows.Forms.OpenFileDialog openJSFileDialog;
        private System.Windows.Forms.Button loadButton;
        private System.Windows.Forms.TextBox outputTextBox;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Button countButton;
        private System.Windows.Forms.Button select1st10Button;
        private System.Windows.Forms.Button select2nd10Button;
        private System.Windows.Forms.Button countTopQueryDocumentButton;
        private System.Windows.Forms.Button countTopQueryEQButton;
        private System.Windows.Forms.Button countMiddleButton;
        private System.Windows.Forms.Button countMiddleMoviesButton;
        private System.Windows.Forms.Button findOneButton;
        private System.Windows.Forms.Button select1st10DescButton;
        private System.Windows.Forms.Button update1stSaveButton;
        private System.Windows.Forms.Button update1stUpdateButton;
        private System.Windows.Forms.Button updateMultipleButton;
        private System.Windows.Forms.Button findAndModifyOldButton;
        private System.Windows.Forms.Button findAndModifyNewButton;
        private System.Windows.Forms.Button mapReduceButton;
        private System.Windows.Forms.Button mapReduceFinalizeButton;
        private System.Windows.Forms.Timer currentOpTimer;
    }
}

