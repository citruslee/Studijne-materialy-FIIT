﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MongoDB.Driver;
using MongoDB.Driver.Builders;
using MongoDB.Bson;
using System.Reflection;
using System.IO;
using MongoDB.Bson.IO;

namespace MongoDBExample
{
    class Controller
    {
        private readonly MongoServer server;
        private readonly MongoDatabase database;
        private readonly MongoCollection<Rating> ratings;

        public Controller()
        {
            JsonWriterSettings.Defaults.Indent = true;

            //connect to the server
            server = MongoServer.Create("mongodb://localhost/?connecttimeout=600000&maxconnectionlifetime=600000&sockettimeout=600000");      

            //connect to the database
            database = server.GetDatabase("MovieLens");

            //recreate collection
            //if (database.CollectionExists("Ratings"))
            //    database.DropCollection("Ratings");

            //database.CreateCollection("Ratings");
            
            //get collection
            ratings = database.GetCollection<Rating>("Ratings");

            //create index
            if (!ratings.IndexExists("MovieID"))
                ratings.CreateIndex("MovieID");
        }

        internal void InsertBatch(IEnumerable<Rating> ratingsEnum)
        {
            ratings.InsertBatch(ratingsEnum);
        }
        
        internal long Count()
        {
            return ratings.Count();
        }

        internal long CountTopQueryDocument()
        {
            var query = new QueryDocument("Value", 5);
            return ratings.Find(query).Count();
        }

        internal long CountTopQueryEQ()
        {
            var query = Query.EQ("Value", 5);
            return ratings.Find(query).Count();
        }

        internal long CountMiddle()
        {
            var query = Query.And(Query.GT("Value", 1), Query.LT("Value", 5));
            return ratings.Find(query).Count();
        }

        internal long CountMiddleMovies()
        {
            var query = Query.And(Query.GT("MovieID", 1900), Query.LT("MovieID", 2100));
            return ratings.Find(query).Count();
        }

        internal Rating FindFirst()
        {
            var query = Query.And(Query.GT("MovieID", 1900), Query.LT("MovieID", 2100));
            return ratings.FindOne(query);
        }

        internal List<Rating> FindFirst10()
        {
            var query = Query.And(Query.GT("MovieID", 1900), Query.LT("MovieID", 2100));
            
            var results = ratings.Find(query).SetLimit(10);

            return new List<Rating>(results);
        }

        internal List<Rating> FindSecond10()
        {
            var query = Query.And(Query.GT("MovieID", 1900), Query.LT("MovieID", 2100));

            var results = ratings.Find(query).SetSkip(10).SetLimit(10);

            return new List<Rating>(results);
        }

        internal List<Rating> FindLast10()
        {
            var query = Query.And(Query.GT("MovieID", 1900), Query.LT("MovieID", 2100));

            var results = ratings.Find(query).SetSortOrder(SortBy.Descending("MovieID")).
                SetLimit(10);

            return new List<Rating>(results);
        }

        internal Rating UpdateFirstSave()
        {
            var query = Query.And(Query.GT("MovieID", 1900), Query.LT("MovieID", 2100));
            var update = Update.Set("Value", 1);

            var rating = ratings.FindOne(query);

            rating.Value = 5;

            ratings.Save(rating);

            return ratings.FindOne(query);
        }

        internal Rating UpdateFirstAtomic()
        {
            var query = Query.And(Query.GT("MovieID", 1900), Query.LT("MovieID", 2100));
            var update = Update.Set("Value", 1);

            ratings.Update(query, update);

            return ratings.FindOne(query);
        }

        internal List<Rating> UpdateFirst10()
        {
            var query = Query.And(Query.GT("MovieID", 2100), Query.LT("MovieID", 2200));
            var update = Update.Set("Value", 1);

            ratings.Update(query, update, UpdateFlags.Multi);

            var results = ratings.Find(query).SetLimit(10);
            return new List<Rating>(results);
        }

        internal BsonDocument FindAndModifyBefore()
        {
            var query = Query.And(Query.GT("MovieID", 1900), Query.LT("MovieID", 2100));
            var update = Update.Set("Value", 3);
            
            return ratings.FindAndModify(query, SortBy.Ascending("MovieID"), 
                update, false).ModifiedDocument;
        }

        internal BsonDocument GetCurrentOp()
        {
            return database.GetCurrentOp();
        }

        internal BsonDocument FindAndModifyAfter()
        {
            var query = Query.And(Query.GT("MovieID", 1900), Query.LT("MovieID", 2100));
            var update = Update.Set("Value", 4);

            return ratings.FindAndModify(query, SortBy.Ascending("MovieID"), 
                update, true).ModifiedDocument;
        }

        private BsonJavaScript MapFunction
        {
            get
            {
                var code = new StreamReader(Assembly.GetExecutingAssembly().
                    GetManifestResourceStream("MongoDBExample.Map.js")).ReadToEnd();

                return new BsonJavaScript(code);
            }
        }

        private BsonJavaScript ReduceFunction
        {
            get
            {
                var code = new StreamReader(Assembly.GetExecutingAssembly().
                    GetManifestResourceStream("MongoDBExample.Reduce.js")).ReadToEnd();

                return new BsonJavaScript(code);
            }
        }

        private BsonJavaScript ReduceWFFunction
        {
            get
            {
                var code = new StreamReader(Assembly.GetExecutingAssembly().
                    GetManifestResourceStream("MongoDBExample.ReduceWF.js")).ReadToEnd();

                return new BsonJavaScript(code);
            }
        }

        private BsonJavaScript FinalizeFunction
        {
            get
            {
                var code = new StreamReader(Assembly.GetExecutingAssembly().
                    GetManifestResourceStream("MongoDBExample.Finalize.js")).ReadToEnd();

                return new BsonJavaScript(code);
            }
        }

        internal BsonDocument MapReduce()
        {
            return ratings.MapReduce(MapFunction, ReduceFunction).Response;
        }

        internal BsonDocument MapReduceFinalize()
        {
            return ratings.MapReduce(MapFunction, ReduceWFFunction,
                MapReduceOptions.SetFinalize(FinalizeFunction).
                SetOutput(MapReduceOutput.Inline)).Response;
        }
    }
}
