﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace MongoDBExample
{
    public partial class LoadDataForm : Form
    {
        private int count = 0;

        struct WorkerData
        {
            public Controller controller;
            public StreamReader file;
        }
    
        public LoadDataForm()
        {
            InitializeComponent();
        }

        internal void Load(Controller controller, string dataFile)
        {
            WorkerData data = new WorkerData();

            data.controller = controller;
            data.file = File.OpenText(dataFile);

            count = File.ReadLines(dataFile).Count();

            SetProgress(0);

            backgroundWorker.RunWorkerAsync(data);

            ShowDialog();
        }

        void SetProgress(int current)
        {
            loadedLabel.Text = string.Format("Loaded: {0}/{1}", current, count);
            progressBar.Maximum = count;
            progressBar.Value = current;
        }

        protected override void OnClosing(CancelEventArgs e)
        {
            backgroundWorker.CancelAsync();
        }

        private void backgroundWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            int current = 0;
            WorkerData data = (WorkerData)e.Argument;

            while (!data.file.EndOfStream)
            {
                if (backgroundWorker.CancellationPending)
                {
                    e.Cancel = true;
                    return;
                }

                string line = data.file.ReadLine();
                
                line.Trim();
                
                if(line != string.Empty)
                {
                    data.controller.SaveRating(new Rating(line));
                }

                SetProgress(++current);
            }
        }

        private void backgroundWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            Close();
        }
    }
}
