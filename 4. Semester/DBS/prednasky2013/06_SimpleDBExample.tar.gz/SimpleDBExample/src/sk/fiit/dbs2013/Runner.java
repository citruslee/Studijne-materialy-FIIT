package sk.fiit.dbs2013;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Properties;

import sk.fiit.dbs2013.models.Student;
import sk.fiit.dbs2013.persistencemanagers.StudentManager;


public class Runner {

	/**
	 * @param args
	 * @throws SQLException 
	 */
	public static void main(String[] args) throws SQLException {
		
		StudentManager sm = new StudentManager();
		for (Student student : sm.getAllStudents()) {
			System.out.println(student.getName() + ":" + student.getVsp());
		}
		
		for (Student student : StudentManager.getAllStudentsOld()) {
			System.out.println(student.getName() + ":" + student.getVsp());
		}
	    
		
	}

}
