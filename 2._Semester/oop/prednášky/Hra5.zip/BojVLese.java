
public class BojVLese implements BojVProstredi {
	public void boj(Energia r, ZlyObor o) {
		o.zjedz(r);		
	}
	public void boj(Energia r, PlachyObor o) {
		r.znizEnergiu(1);
		o.zvysEnergiu(1);
	}
}
