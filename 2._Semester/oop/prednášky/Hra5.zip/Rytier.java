
public class Rytier implements Energia {
	private Poloha poloha;
	private int energia; // aby aj odvodené typy rytierov mohli pracovať s týmto atribútom, čím predsa znižujeme zapuzdrenie
						// riešením by bola metóda setEnergia(int energia), ktorá by len nastavovala energiu na určitú hodnotu

	public Rytier(int energia) {
		this.energia = energia;
	}
	public void nastavEnergiu(int energia) {
		this.energia = energia;
	}
	public int zistiEnergiu() {
		return energia;
	}
	public void zvysEnergiu(int i) {
		energia = energia + i;
	}
	public void znizEnergiu(int i) {
		energia = energia - i;
	}
}
