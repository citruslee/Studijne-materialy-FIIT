
public interface BojVProstredi {
	void boj(Energia r, ZlyObor o);
	void boj(Energia r, PlachyObor o);
}
