
public interface Energia {
	public void nastavEnergiu(int energia);
	public int zistiEnergiu();
	public void zvysEnergiu(int i);
	public void znizEnergiu(int i);
}
