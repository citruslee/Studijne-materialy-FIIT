
public class BojNaLuke implements BojVProstredi {
	public void boj(Energia r, ZlyObor o) {
		if (o.zistiHladny())
			o.zjedz(r);		
	}
	public void boj(Energia r, PlachyObor o) {
		o.utec();		
	}
}
