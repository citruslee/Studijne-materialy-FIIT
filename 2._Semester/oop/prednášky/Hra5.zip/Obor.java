public abstract class Obor implements Energia{
	private Poloha poloha;
	private boolean hladny; // pozri koment�r pri atrib�te energia triedy Rytier
	private int energia;
	
	public Obor() {
	}	
	public Obor(int energia, boolean hladny) {
		this.energia = energia;
		this.hladny = hladny;
	}
	
	public void nastavEnergiu(int energia) {
		this.energia = energia;
	}
	public int zistiEnergiu() {
		return energia;
	}
	public void zvysEnergiu(int i) {
		energia = energia + i;
	}
	public void znizEnergiu(int i) {
		energia = energia - i;
	}
	public void nastavHladny(boolean hladny) {
		this.hladny = hladny;
	}
	public boolean zistiHladny() {
		return hladny;
	}
	public abstract void odveta(Energia r, BojVProstredi b);
}