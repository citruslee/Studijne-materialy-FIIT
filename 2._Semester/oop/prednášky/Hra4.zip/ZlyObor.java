
public class ZlyObor extends Obor {
	public ZlyObor(int energia, boolean hladny) {
		super(energia, hladny);
	}

	public void odveta(Energia r) {
		if (zistiHladny())
			zjedz(r);
	}
	public void zjedz(Energia r) {
		int e = r.zistiEnergiu();
		r.znizEnergiu(e);
		zvysEnergiu(e);
		nastavHladny(false);
	}
}
