
public class Stret {
	public void stret(Obor obor, Energia e) {
		obor.odveta(e);
	}

	public static void main(String[] args) {
//		System.out.println("abc");

		Obor[] obor = new Obor[100];
		Rytier[] rytier = new Rytier[100];
		
		// každý druhý rytier bude dobre obrnený
		for (int i = 0; i < 100; i = i + 2) {
			rytier[i] = new Rytier(40);
		}
		
		for (int i = 1; i < 100; i = i + 2) {
			rytier[i] = new DobreObrnenyRytier(40);
		}
	
		for (int i = 0; i < 10; i++) {
			final int ii = i; // vnútorné triedy môžu pracovať len s finálnymi premennými vonkajšej triedy
			obor[i] = new Obor(5, false) {
				public void odveta(Energia r) {
					r.znizEnergiu(ii);
				}
			};
		}

		for (int i = 10; i < 25; i++) {
			obor[i] = new Obor(20, false);
		}
		
		for (int i = 25; i < 65; i++) {
			obor[i] = new ZlyObor(50, true);
		}
		
		for (int i = 65; i < 100; i++) {
			obor[i] = new PlachyObor(10, false);
		}

		for (int i = 0; i < 100; i++) {
			new Stret().stret(obor[i], rytier[i]);
			System.out.println(i + ":" + "rytier " + rytier[i].zistiEnergiu() + " / " + "obor " + obor[i].zistiEnergiu());
		}
	}

}
