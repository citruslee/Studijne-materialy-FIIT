
public class PlachyObor extends Obor {
	void utec() {
		/*...*/
	}
	void odveta(Rytier r) {
		utec();
	}
}
