public class Obor {
	Poloha poloha;
	boolean hladny;
	int energia;
	
	void odveta(Rytier r) {
		r.znizEnergiu(1);
	}
	int zistiEnergiu() {
		return energia;
	}
	void zvysEnergiu(int i) {
		energia = energia + i;
	}
	void znizEnergiu(int i) {
		energia = energia - i;
	}
}