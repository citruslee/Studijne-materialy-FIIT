
public class ZlyObor extends Obor {
	void odveta(Rytier r) {
		if (hladny)
			zjedz(r);
	}
	void zjedz(Rytier r) {
		int e = r.zistiEnergiu();
		r.znizEnergiu(e);
		zvysEnergiu(e);
		hladny = false;
	}
}
