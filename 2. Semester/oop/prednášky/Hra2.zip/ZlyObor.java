
public class ZlyObor extends Obor {
	ZlyObor(int energia, boolean hladny) {
		super(energia, hladny);
	}

	void odveta(Rytier r) {
		if (hladny)
			zjedz(r);
	}
	void zjedz(Rytier r) {
		int e = r.zistiEnergiu();
		r.znizEnergiu(e);
		zvysEnergiu(e);
		hladny = false;
	}
}
