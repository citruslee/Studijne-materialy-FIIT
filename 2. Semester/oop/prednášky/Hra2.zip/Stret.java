
public class Stret {
	void stret(Obor obor, Rytier rytier) {
		obor.odveta(rytier);
	}

	public static void main(String[] args) {
//		System.out.println("abc");

		Obor[] obor = new Obor[100];
		Rytier[] rytier = new Rytier[100];
		
		for (int i = 0; i < 100; i++) {
			rytier[i] = new Rytier();
			rytier[i].energia = 40;
		}
		
		for (int i = 0; i < 25; i++) {
			obor[i] = new Obor(20, false);
		}
		
		for (int i = 25; i < 65; i++) {
			obor[i] = new ZlyObor(50, true);
		}
		
		for (int i = 65; i < 100; i++) {
			obor[i] = new PlachyObor();
			obor[i].energia = 10;
		}

		for (int i = 0; i < 100; i++) {
			new Stret().stret(obor[i], rytier[i]);
			System.out.println(i + ":" + "rytier " + rytier[i].energia + " / " + "obor " + obor[i].energia);
		}
	}

}
