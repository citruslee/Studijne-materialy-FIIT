public class Obor {
	Poloha poloha;
	boolean hladny;
	int energia;
	
	Obor() {
	}
	
	Obor(int energia, boolean hladny) {
		this.energia = energia;
		this.hladny = hladny;
	}
	
	void odveta(Rytier r) {
		r.znizEnergiu(1);
	}
	int zistiEnergiu() {
		return energia;
	}
	void zvysEnergiu(int i) {
		energia = energia + i;
	}
	void znizEnergiu(int i) {
		energia = energia - i;
	}
}