
public class Rytier {
	Poloha poloha;
	int energia;

	int zistiEnergiu() {
		return energia;
	}
	void zvysEnergiu(int i) {
		energia = energia + i;
	}
	void znizEnergiu(int i) {
		energia = energia - i;
	}
}
