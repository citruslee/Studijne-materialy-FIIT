
public class ZlyObor extends Obor {
	public ZlyObor(int energia, boolean hladny) {
		super(energia, hladny);
	}

	public void odveta(Rytier r) {
		if (hladny)
			zjedz(r);
	}
	public void zjedz(Rytier r) {
		int e = r.zistiEnergiu();
		r.znizEnergiu(e);
		zvysEnergiu(e);
		hladny = false;
	}
}
