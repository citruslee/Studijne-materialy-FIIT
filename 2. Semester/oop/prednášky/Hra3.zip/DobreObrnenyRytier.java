
public class DobreObrnenyRytier extends Rytier {
	public DobreObrnenyRytier(int energia) {
		super(energia);
	}	
	public void znizEnergiu(int i) {
		energia = energia - i/2;
	}

}
