public class Obor {
	private Poloha poloha;
	protected boolean hladny; // pozri koment�r pri atrib�te energia triedy Rytier
	private int energia;
	
	public Obor() {
	}
	
	public Obor(int energia, boolean hladny) {
		this.energia = energia;
		this.hladny = hladny;
	}
	
	public void odveta(Rytier r) {
		r.znizEnergiu(1);
	}
	public int zistiEnergiu() {
		return energia;
	}
	public void zvysEnergiu(int i) {
		energia = energia + i;
	}
	public void znizEnergiu(int i) {
		energia = energia - i;
	}
}