
public class Rytier {
	private Poloha poloha;
	protected int energia; // aby aj odvoden� typy rytierov mohli pracova� s t�mto atrib�tom, ��m predsa zni�ujeme zapuzdrenie
						// rie�en�m by bola met�da setEnergia(int energia), ktor� by len nastavovala energiu na ur�it� hodnotu

	public Rytier(int energia) {
		this.energia = energia;
	}
	public int zistiEnergiu() {
		return energia;
	}
	public void zvysEnergiu(int i) {
		energia = energia + i;
	}
	public void znizEnergiu(int i) {
		energia = energia - i;
	}
}
