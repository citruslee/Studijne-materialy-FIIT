
public class PlachyObor extends Obor {
	public PlachyObor(int energia, boolean hladny) {
		super(energia, hladny);
	}
	public void utec() {
		/*...*/
	}
	public void odveta(Rytier r) {
		utec();
	}
}
